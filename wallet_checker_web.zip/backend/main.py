from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import random

app = FastAPI()

origins = ["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"])

@app.get("/generate")
def generate_wallet():
    mnemonic = " ".join(random.choices(["apple", "banana", "cat", "dog", "echo", "fish", "goat", "hat", "ice", "jug", "kite", "lion"], k=12))
    return {
        "mnemonic": mnemonic,
        "wallet": {
            "address": "1ExampleBTCAddressxyz",
            "public_key": "PublicKeyXYZ",
            "private_key": "PrivateKeyXYZ"
        }
    }
