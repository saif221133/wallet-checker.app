package com.example.walletchecker;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WalletUtils {

    public static String generateMnemonic() {
        return UUID.randomUUID().toString().replace("-", " ");
    }

    public static WalletData deriveAddresses(String mnemonic) {
        WalletData walletData = new WalletData();
        walletData.btcAddress = "1" + mnemonic.hashCode();
        walletData.ethAddress = "0x" + mnemonic.hashCode();
        walletData.dogeAddress = "D" + mnemonic.hashCode();
        walletData.bnbAddress = "bnb" + mnemonic.hashCode();
        walletData.usdtAddress = "0x" + mnemonic.hashCode();
        return walletData;
    }

    public static Map<String, Double> checkBalances(WalletData walletData) {
        Map<String, Double> balances = new HashMap<>();
        OkHttpClient client = new OkHttpClient();

        try {
            balances.put("BTC", 0.0);
            balances.put("ETH", 0.0);
            balances.put("DOGE", 0.0);
            balances.put("BNB", 0.0);
            balances.put("USDT", 0.0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return balances;
    }

    public static void saveToFile(Context context, String mnemonic, WalletData walletData, Map<String, Double> balances) {
        String fileName = "wallet_" + System.currentTimeMillis() + ".txt";
        StringBuilder fileContent = new StringBuilder();
        fileContent.append("Mnemonic: ").append(mnemonic).append("\n");
        fileContent.append("BTC Address: ").append(walletData.btcAddress).append("\n");
        fileContent.append("ETH Address: ").append(walletData.ethAddress).append("\n");
        fileContent.append("DOGE Address: ").append(walletData.dogeAddress).append("\n");
        fileContent.append("BNB Address: ").append(walletData.bnbAddress).append("\n");
        fileContent.append("USDT Address: ").append(walletData.usdtAddress).append("\n\n");

        for (Map.Entry<String, Double> entry : balances.entrySet()) {
            fileContent.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        try {
            File file = new File(context.getExternalFilesDir(null), fileName);
            FileOutputStream outputStream = new FileOutputStream(file);
            outputStream.write(fileContent.toString().getBytes());
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
