package com.example.walletchecker;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    TextView outputText, statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        outputText = findViewById(R.id.outputText);
        statusText = findViewById(R.id.statusText);

        new Handler().postDelayed(() -> {
            String mnemonic = WalletUtils.generateMnemonic();
            outputText.setText("Mnemonic: \n" + mnemonic);

            checkBalances(mnemonic);
        }, 1000);
    }

    private void checkBalances(String mnemonic) {
        new Thread(() -> {
            WalletData walletData = WalletUtils.deriveAddresses(mnemonic);
            Map<String, Double> balances = WalletUtils.checkBalances(walletData);

            StringBuilder balanceOutput = new StringBuilder();
            boolean hasFunds = false;
            for (Map.Entry<String, Double> entry : balances.entrySet()) {
                balanceOutput.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
                if (entry.getValue() > 0) {
                    hasFunds = true;
                }
            }

            if (hasFunds) {
                WalletUtils.saveToFile(this, mnemonic, walletData, balances);
            }

            runOnUiThread(() -> outputText.setText(balanceOutput.toString()));
        }).start();
    }
}
