package com.example.walletchecker;

public class WalletData {
    public String btcAddress;
    public String ethAddress;
    public String dogeAddress;
    public String bnbAddress;
    public String usdtAddress;
}
